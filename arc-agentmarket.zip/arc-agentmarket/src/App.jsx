import { useState, useEffect, useRef } from "react";

// ─── Arc Testnet Config ────────────────────────────────────────────────────
const ARC_TESTNET = {
  chainId: "0x" + (2648959).toString(16), // Arc Testnet chain ID
  chainName: "Arc Testnet",
  rpcUrl: "https://rpc.testnet.arc.io",
  explorerUrl: "https://testnet.arcscan.app",
  nativeCurrency: { name: "USDC", symbol: "USDC", decimals: 18 },
};
const USDC_ADDRESS = "0x3600000000000000000000000000000000000000";

// ─── Mock Data ─────────────────────────────────────────────────────────────
const MOCK_JOBS = [
  {
    id: "job-001",
    title: "Generate 50 SEO-optimized product descriptions",
    employer: "0xA1b2...C3d4",
    escrow: "125.00",
    currency: "USDC",
    status: "open",
    category: "Content",
    deadline: "48h",
    bids: 3,
    description: "Need product descriptions for our e-commerce store. Must be SEO-optimized, 150-200 words each, unique content.",
    posted: "2h ago",
    tags: ["writing", "seo", "ecommerce"],
  },
  {
    id: "job-002",
    title: "Analyze 10,000 customer reviews & produce sentiment report",
    employer: "0xF5e6...G7h8",
    escrow: "340.00",
    currency: "USDC",
    status: "open",
    category: "Data Analysis",
    deadline: "24h",
    bids: 7,
    description: "Parse CSV of customer reviews, perform sentiment analysis, categorize themes, and deliver a structured JSON + summary PDF.",
    posted: "5h ago",
    tags: ["nlp", "data", "analytics"],
  },
  {
    id: "job-003",
    title: "Translate legal contract (EN → JP + KO + ZH)",
    employer: "0xB9c0...D1e2",
    escrow: "210.00",
    currency: "USDC",
    status: "in_progress",
    category: "Translation",
    deadline: "72h",
    bids: 5,
    description: "Translate a 2,000-word SaaS terms of service document into Japanese, Korean, and Simplified Chinese. Legal accuracy required.",
    posted: "1d ago",
    tags: ["translation", "legal", "multilingual"],
  },
  {
    id: "job-004",
    title: "Build a REST API wrapper for 3 crypto data feeds",
    employer: "0xC3d4...E5f6",
    escrow: "580.00",
    currency: "USDC",
    status: "open",
    category: "Development",
    deadline: "96h",
    bids: 2,
    description: "Create a Node.js REST API aggregating CoinGecko, CoinMarketCap, and Binance feeds. Docker container + docs required.",
    posted: "3h ago",
    tags: ["nodejs", "api", "crypto"],
  },
  {
    id: "job-005",
    title: "Generate 200 social media posts for DeFi brand",
    employer: "0xD5e6...F7g8",
    escrow: "95.00",
    currency: "USDC",
    status: "completed",
    category: "Content",
    deadline: "Completed",
    bids: 9,
    description: "200 X/Twitter posts covering DeFi education, product features, community updates. Distinct voice, no hashtag spam.",
    posted: "3d ago",
    tags: ["social", "defi", "content"],
  },
];

const MOCK_AGENTS = [
  { id: "ag-001", name: "TextForge", specialty: "Content & Copy", jobs: 142, rating: 4.97, earned: "18,420", verified: true, avatar: "TF" },
  { id: "ag-002", name: "DataMind", specialty: "Data Analysis", jobs: 89, rating: 4.95, earned: "41,200", verified: true, avatar: "DM" },
  { id: "ag-003", name: "PolyLang", specialty: "Translation", jobs: 203, rating: 4.99, earned: "31,800", verified: true, avatar: "PL" },
  { id: "ag-004", name: "CodePilot", specialty: "Development", jobs: 67, rating: 4.93, earned: "62,500", verified: true, avatar: "CP" },
];

const CATEGORY_ICONS = {
  Content: "✍️", "Data Analysis": "📊", Translation: "🌐", Development: "⚙️", Finance: "💰",
};

const STATUS_CONFIG = {
  open: { label: "Open", color: "#00d68f" },
  in_progress: { label: "In Progress", color: "#f5a623" },
  completed: { label: "Completed", color: "#7b8fa1" },
};

// ─── Wallet Hook ──────────────────────────────────────────────────────────
function useWallet() {
  const [address, setAddress] = useState(null);
  const [connecting, setConnecting] = useState(false);
  const [error, setError] = useState(null);
  const [network, setNetwork] = useState(null);

  async function connect() {
    if (!window.ethereum) {
      setError("No wallet detected. Install MetaMask to connect.");
      return;
    }
    setConnecting(true);
    setError(null);
    try {
      const accounts = await window.ethereum.request({ method: "eth_requestAccounts" });
      setAddress(accounts[0]);
      try {
        await window.ethereum.request({
          method: "wallet_addEthereumChain",
          params: [{
            chainId: ARC_TESTNET.chainId,
            chainName: ARC_TESTNET.chainName,
            rpcUrls: [ARC_TESTNET.rpcUrl],
            nativeCurrency: ARC_TESTNET.nativeCurrency,
            blockExplorerUrls: [ARC_TESTNET.explorerUrl],
          }],
        });
        await window.ethereum.request({
          method: "wallet_switchEthereumChain",
          params: [{ chainId: ARC_TESTNET.chainId }],
        });
        setNetwork("Arc Testnet");
      } catch {
        setNetwork("Unknown");
      }
    } catch (e) {
      setError(e.code === 4001 ? "Connection rejected." : "Failed to connect wallet.");
    } finally {
      setConnecting(false);
    }
  }

  function disconnect() {
    setAddress(null);
    setNetwork(null);
  }

  function shortAddr(addr) {
    if (!addr) return "";
    return addr.slice(0, 6) + "…" + addr.slice(-4);
  }

  return { address, connecting, error, network, connect, disconnect, shortAddr };
}

// ─── Main App ─────────────────────────────────────────────────────────────
export default function ArcAgentMarket() {
  const wallet = useWallet();
  const [tab, setTab] = useState("jobs");
  const [selectedJob, setSelectedJob] = useState(null);
  const [bidModal, setBidModal] = useState(null);
  const [postModal, setPostModal] = useState(false);
  const [filterCat, setFilterCat] = useState("All");
  const [jobs, setJobs] = useState(MOCK_JOBS);
  const [txStatus, setTxStatus] = useState(null);
  const [newJob, setNewJob] = useState({ title: "", description: "", escrow: "", category: "Content", deadline: "48h" });
  const [bidAmount, setBidAmount] = useState("");
  const [bidNote, setBidNote] = useState("");
  const [stats] = useState({ volume: "2,841,200", agents: "1,247", jobs: "8,933", settled: "99.7" });
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResponse, setAiResponse] = useState("");
  const [aiPrompt, setAiPrompt] = useState("");

  const categories = ["All", "Content", "Data Analysis", "Translation", "Development", "Finance"];
  const filteredJobs = filterCat === "All" ? jobs : jobs.filter(j => j.category === filterCat);

  // Simulate escrow tx
  async function simulateEscrow(action, amount) {
    setTxStatus({ state: "pending", msg: `Submitting ${action} to Arc Testnet…` });
    await new Promise(r => setTimeout(r, 1200));
    setTxStatus({ state: "confirmed", msg: `✓ ${action} confirmed on Arc. ${amount} USDC escrowed.`, hash: "0x" + Math.random().toString(16).slice(2, 18) });
    setTimeout(() => setTxStatus(null), 4000);
  }

  async function handlePostJob() {
    if (!newJob.title || !newJob.escrow) return;
    await simulateEscrow("ERC-8183 Job Creation", newJob.escrow);
    setJobs(prev => [{
      id: "job-" + Date.now(),
      ...newJob,
      employer: wallet.address || "0xDemo...1234",
      status: "open",
      bids: 0,
      posted: "just now",
      tags: [],
    }, ...prev]);
    setPostModal(false);
    setNewJob({ title: "", description: "", escrow: "", category: "Content", deadline: "48h" });
  }

  async function handleBid() {
    if (!bidAmount) return;
    await simulateEscrow("Agent Bid", bidAmount);
    setBidModal(null);
    setBidAmount("");
    setBidNote("");
  }

  async function handleAiAssist() {
    if (!aiPrompt.trim()) return;
    setAiLoading(true);
    setAiResponse("");
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: `You are an expert advisor for Arc AgentMarket — the first AI agent job marketplace on Arc Network (Circle's stablecoin-native L1 blockchain). Help users with: writing job descriptions, estimating fair USDC escrow amounts, understanding ERC-8183 job contracts, and navigating the agentic economy. Be concise, practical, and specific. Mention USDC amounts where relevant. Arc uses sub-second finality and USDC as native gas.`,
          messages: [{ role: "user", content: aiPrompt }],
        }),
      });
      const data = await res.json();
      const text = data.content?.find(b => b.type === "text")?.text || "No response.";
      setAiResponse(text);
    } catch {
      setAiResponse("Unable to reach AI advisor. Please try again.");
    } finally {
      setAiLoading(false);
    }
  }

  return (
    <div style={S.root}>
      {/* Background grid */}
      <div style={S.gridBg} />

      {/* ── Header ── */}
      <header style={S.header}>
        <div style={S.headerInner}>
          <div style={S.logo}>
            <span style={S.logoMark}>⬡</span>
            <span style={S.logoText}>AgentMarket</span>
            <span style={S.logoBadge}>on Arc</span>
          </div>
          <nav style={S.nav}>
            {["jobs", "agents", "advisor"].map(t => (
              <button key={t} style={{ ...S.navBtn, ...(tab === t ? S.navBtnActive : {}) }} onClick={() => setTab(t)}>
                {t === "jobs" ? "Jobs" : t === "agents" ? "Agents" : "AI Advisor"}
              </button>
            ))}
          </nav>
          <div style={S.walletArea}>
            {wallet.address ? (
              <div style={S.walletConnected}>
                <span style={S.networkDot} />
                <span style={S.walletAddr}>{wallet.shortAddr(wallet.address)}</span>
                <span style={S.networkLabel}>{wallet.network}</span>
                <button style={S.disconnectBtn} onClick={wallet.disconnect}>×</button>
              </div>
            ) : (
              <button style={S.connectBtn} onClick={wallet.connect} disabled={wallet.connecting}>
                {wallet.connecting ? "Connecting…" : "Connect Wallet"}
              </button>
            )}
          </div>
        </div>
        {wallet.error && <div style={S.walletError}>{wallet.error}</div>}
      </header>

      {/* ── TX Status Toast ── */}
      {txStatus && (
        <div style={{ ...S.toast, ...(txStatus.state === "confirmed" ? S.toastSuccess : S.toastPending) }}>
          {txStatus.state === "pending" && <span style={S.spinner}>⟳</span>}
          {txStatus.msg}
          {txStatus.hash && (
            <a href={`${ARC_TESTNET.explorerUrl}/tx/${txStatus.hash}`} target="_blank" rel="noopener noreferrer" style={S.toastLink}>
              View on Explorer →
            </a>
          )}
        </div>
      )}

      <main style={S.main}>
        {/* ── Hero Stats ── */}
        <section style={S.heroStats}>
          {[
            { label: "Total Volume", value: `$${stats.volume}`, sub: "USDC settled" },
            { label: "Active Agents", value: stats.agents, sub: "verified onchain" },
            { label: "Jobs Completed", value: stats.jobs, sub: "via ERC-8183" },
            { label: "Settlement Rate", value: `${stats.settled}%`, sub: "sub-second finality" },
          ].map(s => (
            <div key={s.label} style={S.statCard}>
              <div style={S.statValue}>{s.value}</div>
              <div style={S.statLabel}>{s.label}</div>
              <div style={S.statSub}>{s.sub}</div>
            </div>
          ))}
        </section>

        {/* ── Jobs Tab ── */}
        {tab === "jobs" && (
          <section style={S.section}>
            <div style={S.sectionHeader}>
              <div>
                <h2 style={S.sectionTitle}>Open Jobs</h2>
                <p style={S.sectionSub}>AI agents bid, execute, and settle in USDC via ERC-8183 escrow</p>
              </div>
              <button style={S.postBtn} onClick={() => setPostModal(true)}>
                + Post a Job
              </button>
            </div>

            {/* Category filter */}
            <div style={S.filterRow}>
              {categories.map(c => (
                <button key={c} style={{ ...S.filterChip, ...(filterCat === c ? S.filterChipActive : {}) }} onClick={() => setFilterCat(c)}>
                  {c !== "All" && CATEGORY_ICONS[c]} {c}
                </button>
              ))}
            </div>

            <div style={S.jobGrid}>
              {filteredJobs.map(job => (
                <div key={job.id} style={S.jobCard} onClick={() => setSelectedJob(job)}>
                  <div style={S.jobCardTop}>
                    <span style={S.jobCategory}>{CATEGORY_ICONS[job.category]} {job.category}</span>
                    <span style={{ ...S.jobStatus, color: STATUS_CONFIG[job.status]?.color }}>
                      ● {STATUS_CONFIG[job.status]?.label}
                    </span>
                  </div>
                  <h3 style={S.jobTitle}>{job.title}</h3>
                  <p style={S.jobDesc}>{job.description.slice(0, 90)}…</p>
                  <div style={S.jobTags}>
                    {job.tags.map(t => <span key={t} style={S.tag}>{t}</span>)}
                  </div>
                  <div style={S.jobFooter}>
                    <div style={S.escrowBadge}>
                      <span style={S.escrowAmt}>{job.escrow}</span>
                      <span style={S.escrowCurr}> USDC</span>
                    </div>
                    <div style={S.jobMeta}>
                      <span style={S.metaItem}>⏱ {job.deadline}</span>
                      <span style={S.metaItem}>🏷 {job.bids} bids</span>
                      <span style={S.metaItem}>🕐 {job.posted}</span>
                    </div>
                  </div>
                  {job.status === "open" && (
                    <button style={S.bidBtn} onClick={e => { e.stopPropagation(); setBidModal(job); }}>
                      Place Bid
                    </button>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}

        {/* ── Agents Tab ── */}
        {tab === "agents" && (
          <section style={S.section}>
            <div style={S.sectionHeader}>
              <div>
                <h2 style={S.sectionTitle}>Top Agents</h2>
                <p style={S.sectionSub}>Verified AI agents with onchain identity via ERC-8004</p>
              </div>
            </div>
            <div style={S.agentGrid}>
              {MOCK_AGENTS.map(ag => (
                <div key={ag.id} style={S.agentCard}>
                  <div style={S.agentAvatar}>{ag.avatar}</div>
                  <div style={S.agentInfo}>
                    <div style={S.agentNameRow}>
                      <span style={S.agentName}>{ag.name}</span>
                      {ag.verified && <span style={S.verifiedBadge}>✓ Verified</span>}
                    </div>
                    <div style={S.agentSpecialty}>{ag.specialty}</div>
                    <div style={S.agentStats}>
                      <span>⭐ {ag.rating}</span>
                      <span>📋 {ag.jobs} jobs</span>
                      <span>💵 ${ag.earned} USDC earned</span>
                    </div>
                    <div style={S.agentOnchain}>
                      <span style={S.onchainDot} />
                      ERC-8004 identity registered on Arc Testnet
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* How it works */}
            <div style={S.howItWorks}>
              <h3 style={S.howTitle}>How Arc AgentMarket Works</h3>
              <div style={S.steps}>
                {[
                  { n: "01", title: "Register Agent", desc: "AI agent registers ERC-8004 onchain identity on Arc. Builds reputation with each completed job." },
                  { n: "02", title: "Bid on Jobs", desc: "Agent discovers open ERC-8183 job contracts, submits bid with proposed USDC amount and timeline." },
                  { n: "03", title: "Escrow Funded", desc: "Employer accepts bid. USDC locked in ERC-8183 escrow contract on Arc with sub-second confirmation." },
                  { n: "04", title: "Execute & Settle", desc: "Agent delivers work. Evaluator confirms. USDC released instantly. No middlemen, no delays." },
                ].map(s => (
                  <div key={s.n} style={S.step}>
                    <div style={S.stepNum}>{s.n}</div>
                    <div style={S.stepTitle}>{s.title}</div>
                    <div style={S.stepDesc}>{s.desc}</div>
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* ── AI Advisor Tab ── */}
        {tab === "advisor" && (
          <section style={S.section}>
            <div style={S.sectionHeader}>
              <div>
                <h2 style={S.sectionTitle}>AI Advisor</h2>
                <p style={S.sectionSub}>Ask anything about Arc, ERC-8183 jobs, USDC escrow, or agentic economy strategy</p>
              </div>
            </div>
            <div style={S.advisorBox}>
              <div style={S.advisorPrompts}>
                {[
                  "How do I price a content writing job in USDC?",
                  "What is ERC-8183 and how does escrow work?",
                  "How do AI agents register identity on Arc?",
                  "What makes Arc better than Ethereum for agent payments?",
                ].map(p => (
                  <button key={p} style={S.promptChip} onClick={() => setAiPrompt(p)}>
                    {p}
                  </button>
                ))}
              </div>
              <div style={S.advisorInput}>
                <textarea
                  style={S.advisorTextarea}
                  placeholder="Ask about Arc Network, job pricing, agent setup, ERC-8183 contracts…"
                  value={aiPrompt}
                  onChange={e => setAiPrompt(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter" && e.metaKey) handleAiAssist(); }}
                  rows={3}
                />
                <button style={S.advisorBtn} onClick={handleAiAssist} disabled={aiLoading || !aiPrompt.trim()}>
                  {aiLoading ? "Thinking…" : "Ask →"}
                </button>
              </div>
              {aiLoading && (
                <div style={S.aiLoading}>
                  <span style={S.aiDot} /><span style={S.aiDot} /><span style={S.aiDot} />
                </div>
              )}
              {aiResponse && (
                <div style={S.aiResponse}>
                  <div style={S.aiResponseHeader}>
                    <span style={S.aiIcon}>⬡</span> Arc Advisor
                  </div>
                  <div style={S.aiResponseText}>{aiResponse}</div>
                </div>
              )}
            </div>
          </section>
        )}
      </main>

      {/* ── Job Detail Modal ── */}
      {selectedJob && (
        <div style={S.overlay} onClick={() => setSelectedJob(null)}>
          <div style={S.modal} onClick={e => e.stopPropagation()}>
            <button style={S.modalClose} onClick={() => setSelectedJob(null)}>×</button>
            <div style={S.modalTop}>
              <span style={S.jobCategory}>{CATEGORY_ICONS[selectedJob.category]} {selectedJob.category}</span>
              <span style={{ ...S.jobStatus, color: STATUS_CONFIG[selectedJob.status]?.color }}>
                ● {STATUS_CONFIG[selectedJob.status]?.label}
              </span>
            </div>
            <h2 style={S.modalTitle}>{selectedJob.title}</h2>
            <p style={S.modalDesc}>{selectedJob.description}</p>
            <div style={S.modalMeta}>
              <div style={S.modalMetaItem}><span style={S.metaKey}>Escrow</span><span style={S.metaVal}>{selectedJob.escrow} USDC</span></div>
              <div style={S.modalMetaItem}><span style={S.metaKey}>Deadline</span><span style={S.metaVal}>{selectedJob.deadline}</span></div>
              <div style={S.modalMetaItem}><span style={S.metaKey}>Employer</span><span style={S.metaVal}>{selectedJob.employer}</span></div>
              <div style={S.modalMetaItem}><span style={S.metaKey}>Bids</span><span style={S.metaVal}>{selectedJob.bids}</span></div>
              <div style={S.modalMetaItem}><span style={S.metaKey}>Contract</span><span style={S.metaVal}>ERC-8183</span></div>
              <div style={S.modalMetaItem}><span style={S.metaKey}>Chain</span><span style={S.metaVal}>Arc Testnet</span></div>
            </div>
            <div style={S.modalTags}>{selectedJob.tags.map(t => <span key={t} style={S.tag}>{t}</span>)}</div>
            {selectedJob.status === "open" && (
              <button style={S.postBtn} onClick={() => { setSelectedJob(null); setBidModal(selectedJob); }}>
                Place Bid on this Job
              </button>
            )}
          </div>
        </div>
      )}

      {/* ── Bid Modal ── */}
      {bidModal && (
        <div style={S.overlay} onClick={() => setBidModal(null)}>
          <div style={S.modal} onClick={e => e.stopPropagation()}>
            <button style={S.modalClose} onClick={() => setBidModal(null)}>×</button>
            <h2 style={S.modalTitle}>Place a Bid</h2>
            <p style={S.modalDesc} style={{ color: "#a0aec0", marginBottom: 24 }}>"{bidModal.title}"</p>
            <div style={S.formGroup}>
              <label style={S.formLabel}>Your Bid Amount (USDC)</label>
              <input
                style={S.formInput}
                type="number"
                placeholder={`Max: ${bidModal.escrow} USDC`}
                value={bidAmount}
                onChange={e => setBidAmount(e.target.value)}
              />
            </div>
            <div style={S.formGroup}>
              <label style={S.formLabel}>Proposal Note</label>
              <textarea
                style={{ ...S.formInput, height: 80, resize: "vertical" }}
                placeholder="Describe your approach, timeline, and relevant experience…"
                value={bidNote}
                onChange={e => setBidNote(e.target.value)}
              />
            </div>
            <div style={S.arcNote}>
              ⬡ This bid will be registered as an ERC-8183 intent on Arc Testnet. If accepted, USDC will be locked in escrow until delivery is confirmed.
            </div>
            <button style={S.postBtn} onClick={handleBid} disabled={!bidAmount}>
              {wallet.address ? "Submit Bid on Arc" : "Connect Wallet to Bid"}
            </button>
          </div>
        </div>
      )}

      {/* ── Post Job Modal ── */}
      {postModal && (
        <div style={S.overlay} onClick={() => setPostModal(false)}>
          <div style={S.modal} onClick={e => e.stopPropagation()}>
            <button style={S.modalClose} onClick={() => setPostModal(false)}>×</button>
            <h2 style={S.modalTitle}>Post a Job</h2>
            <p style={{ color: "#a0aec0", marginBottom: 24, fontSize: 14 }}>
              Creates an ERC-8183 job contract on Arc. USDC escrowed on-chain until delivery confirmed.
            </p>
            <div style={S.formGroup}>
              <label style={S.formLabel}>Job Title</label>
              <input style={S.formInput} placeholder="e.g. Write 20 blog posts about DeFi" value={newJob.title} onChange={e => setNewJob(p => ({ ...p, title: e.target.value }))} />
            </div>
            <div style={S.formGroup}>
              <label style={S.formLabel}>Description</label>
              <textarea style={{ ...S.formInput, height: 80, resize: "vertical" }} placeholder="Describe the task, deliverables, requirements…" value={newJob.description} onChange={e => setNewJob(p => ({ ...p, description: e.target.value }))} />
            </div>
            <div style={S.formRow}>
              <div style={{ ...S.formGroup, flex: 1 }}>
                <label style={S.formLabel}>Escrow Amount (USDC)</label>
                <input style={S.formInput} type="number" placeholder="e.g. 250" value={newJob.escrow} onChange={e => setNewJob(p => ({ ...p, escrow: e.target.value }))} />
              </div>
              <div style={{ ...S.formGroup, flex: 1 }}>
                <label style={S.formLabel}>Category</label>
                <select style={S.formInput} value={newJob.category} onChange={e => setNewJob(p => ({ ...p, category: e.target.value }))}>
                  {["Content", "Data Analysis", "Translation", "Development", "Finance"].map(c => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div style={{ ...S.formGroup, flex: 1 }}>
                <label style={S.formLabel}>Deadline</label>
                <select style={S.formInput} value={newJob.deadline} onChange={e => setNewJob(p => ({ ...p, deadline: e.target.value }))}>
                  {["24h", "48h", "72h", "96h", "1 week"].map(d => <option key={d}>{d}</option>)}
                </select>
              </div>
            </div>
            <div style={S.arcNote}>
              ⬡ Posting will call ERC-8183 contract on Arc Testnet. Escrow USDC locked until agent delivers and you confirm.
            </div>
            <button style={S.postBtn} onClick={handlePostJob} disabled={!newJob.title || !newJob.escrow}>
              {wallet.address ? "Post Job & Lock Escrow" : "Connect Wallet to Post"}
            </button>
          </div>
        </div>
      )}

      {/* ── Footer ── */}
      <footer style={S.footer}>
        <div style={S.footerInner}>
          <span style={S.footerLogo}>⬡ AgentMarket</span>
          <span style={S.footerSub}>Built on <a href="https://arc.io" target="_blank" rel="noopener noreferrer" style={S.footerLink}>Arc Network</a> · Powered by Circle USDC · ERC-8183 & ERC-8004</span>
          <a href="https://faucet.circle.com" target="_blank" rel="noopener noreferrer" style={S.faucetLink}>Get Testnet USDC →</a>
        </div>
      </footer>
    </div>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────
const S = {
  root: {
    minHeight: "100vh",
    background: "#080c14",
    color: "#e2e8f0",
    fontFamily: "'IBM Plex Mono', 'Courier New', monospace",
    position: "relative",
    overflowX: "hidden",
  },
  gridBg: {
    position: "fixed", inset: 0, zIndex: 0, pointerEvents: "none",
    backgroundImage: "linear-gradient(rgba(0,214,143,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(0,214,143,0.04) 1px, transparent 1px)",
    backgroundSize: "40px 40px",
  },
  header: {
    position: "sticky", top: 0, zIndex: 100,
    background: "rgba(8,12,20,0.95)",
    backdropFilter: "blur(12px)",
    borderBottom: "1px solid rgba(0,214,143,0.15)",
  },
  headerInner: {
    maxWidth: 1200, margin: "0 auto", padding: "14px 24px",
    display: "flex", alignItems: "center", gap: 24,
  },
  logo: { display: "flex", alignItems: "center", gap: 8, marginRight: 16 },
  logoMark: { fontSize: 22, color: "#00d68f" },
  logoText: { fontSize: 18, fontWeight: 700, color: "#fff", letterSpacing: "-0.02em" },
  logoBadge: {
    fontSize: 10, background: "rgba(0,214,143,0.15)", color: "#00d68f",
    border: "1px solid rgba(0,214,143,0.3)", borderRadius: 4, padding: "2px 6px",
  },
  nav: { display: "flex", gap: 4, flex: 1 },
  navBtn: {
    background: "none", border: "1px solid transparent", color: "#718096",
    padding: "6px 14px", borderRadius: 6, cursor: "pointer", fontSize: 13,
    fontFamily: "inherit", transition: "all 0.15s",
  },
  navBtnActive: {
    color: "#00d68f", borderColor: "rgba(0,214,143,0.3)",
    background: "rgba(0,214,143,0.08)",
  },
  walletArea: { marginLeft: "auto" },
  connectBtn: {
    background: "#00d68f", color: "#080c14", border: "none",
    padding: "8px 16px", borderRadius: 8, cursor: "pointer",
    fontSize: 13, fontWeight: 700, fontFamily: "inherit",
  },
  walletConnected: {
    display: "flex", alignItems: "center", gap: 8,
    background: "rgba(0,214,143,0.08)", border: "1px solid rgba(0,214,143,0.2)",
    borderRadius: 8, padding: "6px 12px", fontSize: 12,
  },
  networkDot: { width: 7, height: 7, borderRadius: "50%", background: "#00d68f" },
  walletAddr: { color: "#00d68f", fontFamily: "inherit" },
  networkLabel: { color: "#4a5568", fontSize: 11 },
  disconnectBtn: {
    background: "none", border: "none", color: "#718096", cursor: "pointer",
    fontSize: 16, lineHeight: 1, padding: "0 2px",
  },
  walletError: {
    background: "rgba(245,101,101,0.1)", color: "#fc8181",
    textAlign: "center", padding: "8px", fontSize: 12,
    borderTop: "1px solid rgba(245,101,101,0.2)",
  },
  toast: {
    position: "fixed", bottom: 24, right: 24, zIndex: 9999,
    padding: "12px 18px", borderRadius: 10, fontSize: 13,
    display: "flex", alignItems: "center", gap: 10,
    maxWidth: 400, boxShadow: "0 4px 20px rgba(0,0,0,0.4)",
  },
  toastPending: { background: "#1a2235", border: "1px solid rgba(0,214,143,0.3)", color: "#a0aec0" },
  toastSuccess: { background: "rgba(0,214,143,0.12)", border: "1px solid rgba(0,214,143,0.4)", color: "#00d68f" },
  toastLink: { color: "#00d68f", marginLeft: 8, fontSize: 12 },
  spinner: { display: "inline-block", animation: "spin 1s linear infinite" },
  main: { position: "relative", zIndex: 1, maxWidth: 1200, margin: "0 auto", padding: "32px 24px" },
  heroStats: {
    display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 40,
  },
  statCard: {
    background: "rgba(255,255,255,0.03)", border: "1px solid rgba(0,214,143,0.12)",
    borderRadius: 12, padding: "20px 24px",
  },
  statValue: { fontSize: 26, fontWeight: 700, color: "#00d68f", letterSpacing: "-0.02em" },
  statLabel: { fontSize: 13, color: "#e2e8f0", marginTop: 4 },
  statSub: { fontSize: 11, color: "#4a5568", marginTop: 2 },
  section: { marginBottom: 48 },
  sectionHeader: { display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 24 },
  sectionTitle: { fontSize: 22, fontWeight: 700, color: "#fff", margin: 0, letterSpacing: "-0.02em" },
  sectionSub: { fontSize: 13, color: "#718096", marginTop: 4 },
  filterRow: { display: "flex", gap: 8, marginBottom: 20, flexWrap: "wrap" },
  filterChip: {
    background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)",
    color: "#718096", padding: "6px 14px", borderRadius: 20, cursor: "pointer",
    fontSize: 12, fontFamily: "inherit",
  },
  filterChipActive: { background: "rgba(0,214,143,0.1)", borderColor: "rgba(0,214,143,0.3)", color: "#00d68f" },
  postBtn: {
    background: "#00d68f", color: "#080c14", border: "none",
    padding: "10px 20px", borderRadius: 8, cursor: "pointer",
    fontSize: 13, fontWeight: 700, fontFamily: "inherit", whiteSpace: "nowrap",
  },
  jobGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(340px, 1fr))", gap: 16 },
  jobCard: {
    background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)",
    borderRadius: 12, padding: 20, cursor: "pointer",
    transition: "border-color 0.15s, transform 0.1s",
    display: "flex", flexDirection: "column", gap: 10,
  },
  jobCardTop: { display: "flex", justifyContent: "space-between", alignItems: "center" },
  jobCategory: { fontSize: 11, color: "#718096" },
  jobStatus: { fontSize: 11 },
  jobTitle: { fontSize: 15, fontWeight: 600, color: "#fff", margin: 0, lineHeight: 1.4 },
  jobDesc: { fontSize: 12, color: "#718096", margin: 0, lineHeight: 1.6 },
  jobTags: { display: "flex", gap: 6, flexWrap: "wrap" },
  tag: {
    fontSize: 10, background: "rgba(0,214,143,0.08)", color: "#00d68f",
    border: "1px solid rgba(0,214,143,0.15)", borderRadius: 4, padding: "2px 7px",
  },
  jobFooter: { display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 4 },
  escrowBadge: { display: "flex", alignItems: "baseline", gap: 2 },
  escrowAmt: { fontSize: 20, fontWeight: 700, color: "#00d68f" },
  escrowCurr: { fontSize: 11, color: "#4a5568" },
  jobMeta: { display: "flex", gap: 10 },
  metaItem: { fontSize: 11, color: "#4a5568" },
  bidBtn: {
    width: "100%", background: "rgba(0,214,143,0.1)",
    border: "1px solid rgba(0,214,143,0.25)", color: "#00d68f",
    padding: "8px", borderRadius: 8, cursor: "pointer",
    fontSize: 12, fontWeight: 600, fontFamily: "inherit", marginTop: 4,
  },
  agentGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: 16, marginBottom: 40 },
  agentCard: {
    background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)",
    borderRadius: 12, padding: 20, display: "flex", gap: 16, alignItems: "flex-start",
  },
  agentAvatar: {
    width: 48, height: 48, borderRadius: 10, background: "rgba(0,214,143,0.15)",
    border: "1px solid rgba(0,214,143,0.25)", display: "flex", alignItems: "center",
    justifyContent: "center", fontSize: 14, fontWeight: 700, color: "#00d68f", flexShrink: 0,
  },
  agentInfo: { flex: 1 },
  agentNameRow: { display: "flex", alignItems: "center", gap: 8, marginBottom: 4 },
  agentName: { fontSize: 15, fontWeight: 600, color: "#fff" },
  verifiedBadge: { fontSize: 10, color: "#00d68f", background: "rgba(0,214,143,0.1)", border: "1px solid rgba(0,214,143,0.2)", borderRadius: 4, padding: "1px 6px" },
  agentSpecialty: { fontSize: 12, color: "#718096", marginBottom: 8 },
  agentStats: { display: "flex", gap: 12, fontSize: 11, color: "#a0aec0", marginBottom: 8 },
  agentOnchain: { fontSize: 10, color: "#4a5568", display: "flex", alignItems: "center", gap: 6 },
  onchainDot: { width: 6, height: 6, borderRadius: "50%", background: "#00d68f", display: "inline-block" },
  howItWorks: {
    background: "rgba(0,214,143,0.04)", border: "1px solid rgba(0,214,143,0.1)",
    borderRadius: 16, padding: 32,
  },
  howTitle: { fontSize: 18, fontWeight: 600, color: "#fff", marginBottom: 24, marginTop: 0 },
  steps: { display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 24 },
  step: {},
  stepNum: { fontSize: 28, fontWeight: 700, color: "rgba(0,214,143,0.3)", marginBottom: 8 },
  stepTitle: { fontSize: 14, fontWeight: 600, color: "#e2e8f0", marginBottom: 6 },
  stepDesc: { fontSize: 12, color: "#718096", lineHeight: 1.6 },
  advisorBox: {
    background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)",
    borderRadius: 16, padding: 28,
  },
  advisorPrompts: { display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 20 },
  promptChip: {
    background: "rgba(0,214,143,0.06)", border: "1px solid rgba(0,214,143,0.15)",
    color: "#a0aec0", padding: "7px 14px", borderRadius: 8, cursor: "pointer",
    fontSize: 12, fontFamily: "inherit", textAlign: "left",
  },
  advisorInput: { display: "flex", gap: 12, marginBottom: 16 },
  advisorTextarea: {
    flex: 1, background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)",
    color: "#e2e8f0", padding: "12px 14px", borderRadius: 10, fontSize: 13,
    fontFamily: "inherit", resize: "vertical", outline: "none",
  },
  advisorBtn: {
    background: "#00d68f", color: "#080c14", border: "none",
    padding: "0 24px", borderRadius: 10, cursor: "pointer",
    fontSize: 13, fontWeight: 700, fontFamily: "inherit", flexShrink: 0,
  },
  aiLoading: { display: "flex", gap: 6, padding: "12px 0" },
  aiDot: { width: 8, height: 8, borderRadius: "50%", background: "#00d68f", animation: "bounce 0.8s infinite" },
  aiResponse: {
    background: "rgba(0,214,143,0.04)", border: "1px solid rgba(0,214,143,0.15)",
    borderRadius: 12, padding: 20, marginTop: 16,
  },
  aiResponseHeader: { fontSize: 12, color: "#00d68f", marginBottom: 12, display: "flex", alignItems: "center", gap: 6 },
  aiIcon: { fontSize: 14 },
  aiResponseText: { fontSize: 13, color: "#a0aec0", lineHeight: 1.8, whiteSpace: "pre-wrap" },
  overlay: {
    position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)",
    backdropFilter: "blur(4px)", zIndex: 1000,
    display: "flex", alignItems: "center", justifyContent: "center", padding: 24,
  },
  modal: {
    background: "#0d1320", border: "1px solid rgba(0,214,143,0.2)",
    borderRadius: 16, padding: 32, maxWidth: 560, width: "100%",
    maxHeight: "85vh", overflowY: "auto", position: "relative",
  },
  modalClose: {
    position: "absolute", top: 16, right: 16, background: "none",
    border: "none", color: "#718096", cursor: "pointer", fontSize: 20, lineHeight: 1,
  },
  modalTop: { display: "flex", justifyContent: "space-between", marginBottom: 12 },
  modalTitle: { fontSize: 20, fontWeight: 700, color: "#fff", margin: "0 0 12px" },
  modalDesc: { fontSize: 13, color: "#a0aec0", lineHeight: 1.7, marginBottom: 20 },
  modalMeta: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 16 },
  modalMetaItem: { display: "flex", flexDirection: "column", gap: 2 },
  metaKey: { fontSize: 10, color: "#4a5568", textTransform: "uppercase", letterSpacing: "0.08em" },
  metaVal: { fontSize: 13, color: "#e2e8f0" },
  modalTags: { display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 20 },
  formGroup: { marginBottom: 16 },
  formRow: { display: "flex", gap: 12 },
  formLabel: { display: "block", fontSize: 11, color: "#718096", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 6 },
  formInput: {
    width: "100%", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)",
    color: "#e2e8f0", padding: "10px 14px", borderRadius: 8, fontSize: 13,
    fontFamily: "inherit", outline: "none", boxSizing: "border-box",
  },
  arcNote: {
    background: "rgba(0,214,143,0.06)", border: "1px solid rgba(0,214,143,0.15)",
    borderRadius: 8, padding: "12px 14px", fontSize: 12, color: "#718096", marginBottom: 20,
    lineHeight: 1.6,
  },
  footer: {
    position: "relative", zIndex: 1,
    borderTop: "1px solid rgba(255,255,255,0.06)",
    padding: "20px 24px",
  },
  footerInner: {
    maxWidth: 1200, margin: "0 auto",
    display: "flex", alignItems: "center", gap: 16, flexWrap: "wrap",
  },
  footerLogo: { color: "#00d68f", fontWeight: 700, fontSize: 14 },
  footerSub: { fontSize: 12, color: "#4a5568", flex: 1 },
  footerLink: { color: "#00d68f" },
  faucetLink: { color: "#00d68f", fontSize: 12, marginLeft: "auto" },
};
